thank you for downloading my low poly pack!

everything is made in blender.

more will come in the future!